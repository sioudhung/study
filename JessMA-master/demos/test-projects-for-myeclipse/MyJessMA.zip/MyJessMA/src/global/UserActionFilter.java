package global;

import org.jessma.mvc.AbstractActionFilter;
import org.jessma.mvc.ActionExecutor;
import org.jessma.util.Logger;

public class UserActionFilter extends AbstractActionFilter
{
	Logger logger = Logger.getDefaultLogger();
	
	@Override
	public String doFilter(ActionExecutor executor) throws Exception
	{
		logger.debug(">>> User Action Filter (%s#%s())", 
		executor.getAction().getClass().getName(), 
		executor.getEntryMethod().getName());
		String result = executor.invoke();
		logger.debug("User Action Filter <<<");
		
		return result;
	}
}
