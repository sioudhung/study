package vo;

public class Experence extends SimpleVO
{
	public Experence()
	{
		super();
	}
	
	public Experence(int id, String name)
	{
		super(id, name);
	}
}
